namespace CAS
{
    public abstract class Expressao
    {
        public abstract override string ToString();
        public abstract Expressao Derivar(Expressao s);

        public static Expressao operator +(Expressao a, Expressao b) => new Soma(a, b);
        public static Expressao operator -(Expressao a, Expressao b) => new Subtracao(a, b);
        public static Expressao operator *(Expressao a, Expressao b) => new Multiplicacao(a, b);
        public static Expressao operator /(Expressao a, Expressao b) => new Divisao(a, b);

        public static implicit operator Expressao(int v) => new Numero(v);
        public static implicit operator Expressao(string s) => new Simbolo(s);
        public abstract override Simplificar(Expressao s);
    }

    public class Numero : Expressao
    {
        int valor;
        public Numero(int v) => this.valor = v;
        public override string ToString() => $"{valor.ToString()}";
        public override Expressao Derivar(Expressao s) => new Numero(0); 
    }

    public class Simbolo : Expressao
    {
        string simbolo;

        public Simbolo(string s) => this.simbolo = s;  

        public override string ToString() => simbolo;

        public override Expressao Derivar(Expressao s) 
        {
            return this.simbolo == s.ToString() ? new Numero(1) : new Numero(0); 
        }
    }

    public class Soma : Expressao
    {
        Expressao a, b;

        public Soma(Expressao a, Expressao b)
        {
            this.a = a;
            this.b = b;
        }
        
        public override string ToString() => $"{a} + {b}";

        public override Expressao Derivar(Expressao s)
        {
            return new Soma(a.Derivar(s), b.Derivar(s)); 
        }
    }

    public class Subtracao : Expressao
    {
        Expressao a, b;

        public Subtracao(Expressao a, Expressao b)
        {
            this.a = a;
            this.b = b;
        }

        public override string ToString() => $"{a} - {b}";

        public override Expressao Derivar(Expressao s)
        {
            return new Subtracao(a.Derivar(s), b.Derivar(s)); 
        }
    }

    public class Divisao : Expressao
    {
        Expressao x, y;

        public Divisao(Expressao x, Expressao y)
        {
            this.x = x;
            this.y = y;
        }

        public override string ToString() => $"{x} / {y}";

        public override Expressao Derivar(Expressao s)
        {
            return new Divisao(
                new Subtracao(
                    new Multiplicacao(x.Derivar(s), y),
                    new Multiplicacao(x, y.Derivar(s))),
                new Multiplicacao(y, y)); 
        }
    }

    public class Multiplicacao : Expressao
    {
        Expressao x, y;

        public Multiplicacao(Expressao x, Expressao y)
        {
            this.x = x;
            this.y = y;
        }

        public override string ToString() => $"{x} * {y}";

        public override Expressao Derivar(Expressao s)
        {
            return new Soma(
                new Multiplicacao(x.Derivar(s), y),
                new Multiplicacao(x, y.Derivar(s))); // Corrigido para retornar o resultado
        }
    }
}
