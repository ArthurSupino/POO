﻿using CAS;

Expressao a = 10;
Expressao b = "b";

Expressao soma = a + b;
Console.WriteLine(soma);