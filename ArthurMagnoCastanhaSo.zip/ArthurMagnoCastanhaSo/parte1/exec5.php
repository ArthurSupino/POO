<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Entrada de Senha</title>
</head>
<body>
    <h1>Digite sua Senha</h1>
    
    <form method="POST" action="">
        <!-- Campo para a senha (oculta os caracteres) -->
        Senha: <input type="password" name="senha" required><br><br>
        
        <!-- Botão de envio -->
        <input type="submit" value="Enviar">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Captura a senha enviada pelo formulário
        $senha = htmlspecialchars($_POST['senha']);
        
        // Nome do arquivo onde a senha será armazenada
        $arquivo = "senhas.txt";

        // Abre o arquivo para escrita (append) e salva a senha
        $file = fopen($arquivo, "a");
        if ($file) {
            // Escreve a senha no arquivo com uma quebra de linha
            fwrite($file, $senha . "\n");
            fclose($file);
            echo "<p>Senha salva com sucesso!</p>";
        } else {
            echo "<p>Erro ao salvar a senha!</p>";
        }
    }
    ?>
</body>
</html>

