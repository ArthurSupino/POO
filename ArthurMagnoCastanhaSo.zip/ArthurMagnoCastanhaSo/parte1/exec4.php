<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Formulário com Diferentes Entradas</title>
</head>
<body>
    <h1>Formulário com Diferentes Entradas</h1>
    <form method="POST" action="">
        <!-- Caixa de texto -->
        Nome: <input type="text" name="nome" required><br><br>

        <!-- Checkboxes -->
        Escolha suas linguagens de programação favoritas: <br>
        <input type="checkbox" name="linguagens[]" value="PHP"> PHP<br>
        <input type="checkbox" name="linguagens[]" value="JavaScript"> JavaScript<br>
        <input type="checkbox" name="linguagens[]" value="Python"> Python<br>
        <input type="checkbox" name="linguagens[]" value="Java"> Java<br><br>

        <!-- Múltipla escolha (botões de rádio) -->
        Qual o seu nível de experiência em programação? <br>
        <input type="radio" name="nivel" value="Iniciante" required> Iniciante<br>
        <input type="radio" name="nivel" value="Intermediário" required> Intermediário<br>
        <input type="radio" name="nivel" value="Avançado" required> Avançado<br><br>

        <!-- Menu dropdown -->
        Selecione o seu sistema operacional: <br>
        <select name="sistema" required>
            <option value="">Escolha...</option>
            <option value="Windows">Windows</option>
            <option value="Linux">Linux</option>
            <option value="MacOS">MacOS</option>
            <option value="Outro">Outro</option>
        </select><br><br>

        <!-- Botão de envio -->
        <input type="submit" value="Enviar">
    </form>

    <p>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Captura os valores enviados pelo formulário
        $nome = htmlspecialchars($_POST['nome']);
        $linguagens = isset($_POST['linguagens']) ? $_POST['linguagens'] : [];
        $nivel = htmlspecialchars($_POST['nivel']);
        $sistema = htmlspecialchars($_POST['sistema']);

        // Exibe os dados na tela
        echo "<h2>Dados Recebidos</h2>";
        echo "Nome: " . $nome . "<br>";
        
        // Exibe as linguagens selecionadas
        if (!empty($linguagens)) {
            echo "Linguagens de programação favoritas: " . implode(", ", $linguagens) . "<br>";
        } else {
            echo "Nenhuma linguagem de programação selecionada.<br>";
        }

        // Exibe o nível de experiência
        echo "Nível de experiência: " . $nivel . "<br>";

        // Exibe o sistema operacional selecionado
        echo "Sistema Operacional: " . $sistema . "<br>";
    }
    ?>
    </p>
</body>
</html>

