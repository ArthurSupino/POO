<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Calculadora Simples</title>
</head>
<body>
    <h1>Calculadora Simples</h1>
    <p>
        <form method="POST" action="">
            <!-- Input para os números -->
            Digite o primeiro número: <input type="number" name="num1" step="0.01" required><br><br>
            Digite o segundo número: <input type="number" name="num2" step="0.01" required><br><br>

            <!-- Seleção da operação desejada -->
            Selecione a operação: <br>
            <input type="radio" id="soma" name="operacao" value="soma" required>
            <label for="soma">Soma (+)</label><br>
            
            <input type="radio" id="subtracao" name="operacao" value="subtracao" required>
            <label for="subtracao">Subtração (-)</label><br>
            
            <input type="radio" id="multiplicacao" name="operacao" value="multiplicacao" required>
            <label for="multiplicacao">Multiplicação (*)</label><br>
            
            <input type="radio" id="divisao" name="operacao" value="divisao" required>
            <label for="divisao">Divisão (/)</label><br><br>
            
            <!-- Botão de envio -->
            <input type="submit" value="Calcular">
        </form>
    </p>
    
    <p>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obter os valores inseridos
        $num1 = htmlspecialchars($_POST['num1']);
        $num2 = htmlspecialchars($_POST['num2']);
        $operacao = htmlspecialchars($_POST['operacao']);
        $resultado = "";

        // Verificar qual operação foi selecionada e realizar o cálculo
        switch ($operacao) {
            case "soma":
                $resultado = $num1 + $num2;
                echo "Resultado da Soma: " . $resultado;
                break;
            case "subtracao":
                $resultado = $num1 - $num2;
                echo "Resultado da Subtração: " . $resultado;
                break;
            case "multiplicacao":
                $resultado = $num1 * $num2;
                echo "Resultado da Multiplicação: " . $resultado;
                break;
            case "divisao":
                if ($num2 != 0) {
                    $resultado = $num1 / $num2;
                    echo "Resultado da Divisão: " . $resultado;
                } else {
                    echo "Erro: Divisão por zero não é permitida.";
                }
                break;
            default:
                echo "Operação inválida.";
        }
    }
    ?>
    </p>
</body>
</html>

