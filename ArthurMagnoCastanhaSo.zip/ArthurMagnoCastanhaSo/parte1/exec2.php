<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Exercicio 1 da parte 1</title>
</head>
<body>
    <h1>Aqui iremos recolher os dados</h1>
    <p>
        <form method="POST" action="">
            Digite seu nome: <input type="text" name="nome" required><br><br>
            Digite sua idade: <input type="number" name="idade" step="1" required><br><br>
            Digite seu sexo: <input type="text" name="sexo" required><br><br>
            Digite sua altura: <input type="number" name="altura" step="0.01" required><br><br>
            Digite seu peso: <input type="number" name="peso" step="0.1" required><br><br>
            <input type="submit" value="Enviar">
        </form>
    </p>
    <p>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize input
        $nome = htmlspecialchars($_POST['nome']);
        $idade = htmlspecialchars($_POST['idade']);
        $sexo = htmlspecialchars($_POST['sexo']);
        $altura = htmlspecialchars($_POST['altura']);
        $peso = htmlspecialchars($_POST['peso']);

        // Preparar os dados para salvar no arquivo
        $dados = "Nome: " . $nome . "\n" .
                 "Idade: " . $idade . "\n" .
                 "Sexo: " . $sexo . "\n" .
                 "Altura: " . $altura . "\n" .
                 "Peso: " . $peso . "\n" .
                 "-------------------------\n";

        // Escrever os dados no arquivo.txt
        $arquivo = 'dados2.txt';
        file_put_contents($arquivo, $dados, FILE_APPEND);

        // Exibir os dados na página
        echo "<h2>Seus Dados</h2>";
        echo "Seu nome: " . $nome . "<br>";
        echo "Sua idade: " . $idade . "<br>";
        echo "Seu sexo: " . $sexo . "<br>";
        echo "Sua altura: " . $altura . "<br>";
        echo "Seu peso: " . $peso . "<br>";
    }
    ?>
    </p>
</body>
</html>

