<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['nome'] = htmlspecialchars($_POST['nome']);
    $_SESSION['data_nascimento'] = htmlspecialchars($_POST['data_nascimento']);
    $_SESSION['endereco'] = htmlspecialchars($_POST['endereco']);
    $_SESSION['curso'] = htmlspecialchars($_POST['curso']);
    $_SESSION['telefone'] = htmlspecialchars($_POST['telefone']);
    $_SESSION['email'] = htmlspecialchars($_POST['email']);

    header("Location: exibe_matricula.php");
    exit();
} else {
    echo "Método de requisição inválido.";
}
?>
