<?php
session_start();

if (isset($_SESSION['nome'])) {
    echo "<h1>Dados da Matrícula</h1>";
    echo "<p>Nome: " . htmlspecialchars($_SESSION['nome']) . "</p>";
    echo "<p>Data de Nascimento: " . htmlspecialchars($_SESSION['data_nascimento']) . "</p>";
    echo "<p>Endereço: " . htmlspecialchars($_SESSION['endereco']) . "</p>";
    echo "<p>Curso: " . htmlspecialchars($_SESSION['curso']) . "</p>";
    echo "<p>Telefone: " . htmlspecialchars($_SESSION['telefone']) . "</p>";
    echo "<p>E-mail: " . htmlspecialchars($_SESSION['email']) . "</p>";
} else {
    echo "Nenhum dado de matrícula encontrado.";
}
?>

