<?php
$nomeArquivo = "nomes.txt";
$arquivo = fopen($nomeArquivo, "r");

if ($arquivo) {
    while (($linha = fgets($arquivo)) !== false) {
        echo htmlspecialchars($linha) . "<br>";
    }
    fclose($arquivo);
} else {
    echo "Erro ao abrir o arquivo!";
}
?>

