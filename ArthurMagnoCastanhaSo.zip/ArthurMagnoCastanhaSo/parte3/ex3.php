<?php
$nomeArquivo = "linhas.txt";
$arquivo = fopen($nomeArquivo, "r");

if ($arquivo) {
    $conteudo = fread($arquivo, filesize($nomeArquivo));
    echo nl2br($conteudo);
    fclose($arquivo);
} else {
    echo "Erro ao abrir o arquivo!";
}
?>

