<?php
$nomeArquivo = "linhas.txt";
$arquivo = fopen($nomeArquivo, "r");

if ($arquivo) {
    while (($linha = fgets($arquivo)) !== false) {
        echo $linha . "<br>";
    }
    fclose($arquivo);
} else {
    echo "Erro ao abrir o arquivo!";
}
?>

