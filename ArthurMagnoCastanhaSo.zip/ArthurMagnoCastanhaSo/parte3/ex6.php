<?php
$nomes = ["Alice", "Bob", "Charlie", "Diana", "Eva", "Frank", "Grace", "Hannah", "Ivy", "Jack"];
$nomeArquivo = "nomes.txt";
$arquivo = fopen($nomeArquivo, "w");

if ($arquivo) {
    foreach ($nomes as $nome) {
        fwrite($arquivo, $nome . "\n");
    }
    fclose($arquivo);
    echo "Arquivo '$nomeArquivo' criado com sucesso!";
} else {
    echo "Erro ao criar o arquivo!";
}
?>

