<?php
function copiarArquivo($origem, $destino) {
    if (copy($origem, $destino)) {
        return "Arquivo copiado com sucesso de '$origem' para '$destino'.";
    } else {
        return "Falha ao copiar o arquivo de '$origem' para '$destino'.";
    }
}

// Teste da função
$arquivoOrigem = "caminho/para/arquivo_origem.txt";
$arquivoDestino = "caminho/para/arquivo_destino.txt";
echo copiarArquivo($arquivoOrigem, $arquivoDestino);
?>

