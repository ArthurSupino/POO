<?php
function procurarPalavraNoArquivo($nomeArquivo, $palavra) {
    $arquivo = fopen($nomeArquivo, "r");
    $linhasEncontradas = [];

    if ($arquivo) {
        $numeroLinha = 1;
        while (($linha = fgets($arquivo)) !== false) {
            if (stripos($linha, $palavra) !== false) {
                $linhasEncontradas[] = $numeroLinha;
            }
            $numeroLinha++;
        }
        fclose($arquivo);

        if (empty($linhasEncontradas)) {
            return "A palavra '$palavra' não foi encontrada em nenhuma linha.";
        } else {
            return "A palavra '$palavra' foi encontrada nas seguintes linhas: " . implode(", ", $linhasEncontradas);
        }
    } else {
        return "Erro ao abrir o arquivo '$nomeArquivo'.";
    }
}

// Teste da função
$nomeArquivo = "exemplo.txt";
$palavra = "procura";
echo procurarPalavraNoArquivo($nomeArquivo, $palavra);
?>

