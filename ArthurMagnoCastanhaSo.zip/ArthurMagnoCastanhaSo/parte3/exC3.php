<?php
function verificarECriarDiretorio($caminho) {
    if (!file_exists($caminho)) {
        if (mkdir($caminho, 0777, true)) {
            return "Diretório '$caminho' criado com sucesso!";
        } else {
            return "Falha ao criar o diretório '$caminho'.";
        }
    } else {
        return "O diretório '$caminho' já existe.";
    }
}

// Teste da função
$caminhoDiretorio = "novo_diretorio";
echo verificarECriarDiretorio($caminhoDiretorio);
?>

