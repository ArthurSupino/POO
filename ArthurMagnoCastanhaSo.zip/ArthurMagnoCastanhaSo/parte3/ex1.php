<?php
$nomeArquivo = "linhas.txt";
$arquivo = fopen($nomeArquivo, "w");

if ($arquivo) {
    for ($i = 1; $i <= 10; $i++) {
        fwrite($arquivo, "Linha $i\n");
    }
    fwrite($arquivo, "mais uma linha\n");
    fclose($arquivo);
    echo "Arquivo '$nomeArquivo' criado com sucesso!";
} else {
    echo "Erro ao criar o arquivo!";
}
?>

