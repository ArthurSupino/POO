<?php
$nomeArquivo = "ex6data.txt";
$arquivo = fopen($nomeArquivo, "w");

if ($arquivo) {
    for ($i = 1; $i <= 10; $i++) {
        $chave = "chave" . $i;
        $valor = rand(1, 100); // Valor aleatório entre 1 e 100
        fwrite($arquivo, "$chave:$valor\n");
    }
    fclose($arquivo);
    echo "Arquivo '$nomeArquivo' criado com sucesso!";
} else {
    echo "Erro ao criar o arquivo!";
}
?>

