
<?php 

$nomearquivo = "randomInts.txt";
$arquivo = fopen($nomearquivo , "w") or die ("Impossible to open this file ... ");

for($i = 0 ; $i < 20 ; $i++ )
{
        $g = rand(10 , 100) . "\n";
        fwrite($arquivo , $g);
}

        fclose($arquivo);


?>

