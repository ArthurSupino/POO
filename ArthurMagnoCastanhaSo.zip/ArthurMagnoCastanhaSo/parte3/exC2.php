<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciador de Senhas</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 5px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>Gerenciador de Senhas</h1>

    <!-- Formulário para adicionar usuário e senha -->
    <h2>Adicionar Usuário e Senha</h2>
    <form method="POST" action="">
        Nome: <input type="text" name="nome" required><br><br>
        Senha: <input type="password" name="senha" required><br><br>
        <input type="submit" name="salvar" value="Salvar">
    </form>

    <!-- Formulário para ler e mostrar o conteúdo do arquivo -->
    <h2>Mostrar Conteúdo do Arquivo</h2>
    <form method="POST" action="">
        <input type="submit" name="mostrar" value="Mostrar Conteúdo">
    </form>

    <!-- Formulário para buscar senha por nome -->
    <h2>Buscar Senha</h2>
    <form method="POST" action="">
        Nome: <input type="text" name="nome_busca" required><br><br>
        <input type="submit" name="buscar" value="Buscar Senha">
    </form>

    <?php
    $nomeArquivo = "usuarios.txt";

    // Salvar nome e senha no arquivo
    if (isset($_POST['salvar'])) {
        $nome = htmlspecialchars($_POST['nome']);
        $senha = htmlspecialchars($_POST['senha']);
        $linha = "$nome:$senha\n";
        file_put_contents($nomeArquivo, $linha, FILE_APPEND);
        echo "<p>Usuário '$nome' adicionado com sucesso!</p>";
    }

    // Mostrar o conteúdo do arquivo
    if (isset($_POST['mostrar'])) {
        if (file_exists($nomeArquivo)) {
            $conteudo = file($nomeArquivo);
            echo "<h2>Conteúdo do Arquivo</h2>";
            echo "<table><tr><th>Nome</th><th>Senha</th></tr>";
            foreach ($conteudo as $linha) {
                list($nome, $senha) = explode(':', trim($linha));
                echo "<tr><td>" . htmlspecialchars($nome) . "</td><td>" . htmlspecialchars($senha) . "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>Arquivo não encontrado!</p>";
        }
    }

    // Buscar senha por nome
    if (isset($_POST['buscar'])) {
        $nomeBusca = htmlspecialchars($_POST['nome_busca']);
        if (file_exists($nomeArquivo)) {
            $conteudo = file($nomeArquivo);
            $encontrado = false;
            foreach ($conteudo as $linha) {
                list($nome, $senha) = explode(':', trim($linha));
                if ($nome === $nomeBusca) {
                    echo "<p>Senha para '$nomeBusca': " . htmlspecialchars($senha) . "</p>";
                    $encontrado = true;
                    break;
                }
            }
            if (!$encontrado) {
                echo "<p>Usuário '$nomeBusca' não encontrado.</p>";
            }
        } else {
            echo "<p>Arquivo não encontrado!</p>";
        }
    }
    ?>
</body>
</html>

