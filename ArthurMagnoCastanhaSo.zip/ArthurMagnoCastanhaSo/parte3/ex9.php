<?php

$nomearquivo = "randomInts.txt";

// Verifica se o arquivo existe
if (file_exists($nomearquivo)) {
    // Lê o conteúdo do arquivo
    $conteudo = file($nomearquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    // Converte o conteúdo para um array de inteiros
    $numeros = array_map('intval', $conteudo);

    // Ordena o array em ordem crescente
    sort($numeros);

    // Mostra o vetor ordenado
    echo "<h2>Vetores Ordenados:</h2>";
    echo "<pre>";
    print_r($numeros);
    echo "</pre>";
} else {
    echo "Arquivo '$nomearquivo' não encontrado.";
}

?>

