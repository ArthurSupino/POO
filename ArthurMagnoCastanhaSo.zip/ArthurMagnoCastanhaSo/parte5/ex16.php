<?php

$entrada = readline("Digite um número inteiro: ");

if (filter_var($entrada, FILTER_VALIDATE_INT) === false) {
    echo "O valor digitado não é um número inteiro. O programa será abortado.<br>";
} else {
    $n = (int)$entrada;
    $fatorial = 1;

    for ($i = 1; $i <= $n; $i++) {
        $fatorial *= $i;
    }

    echo "O fatorial de $n é: $fatorial<br>";
}

?>

