<?php

$numero = (int)readline("Digite um número: ");

$count = 0;

for ($i = $numero * 2; $i < 1000; $i += $numero) {
    $count++;
}

echo "Quantidade de múltiplos de $numero maiores que ele e menores que 1000: $count<br>";

?>

