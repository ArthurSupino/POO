<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = htmlspecialchars($_POST['nome']);
    $mae = htmlspecialchars($_POST['mae']);
    $pai = htmlspecialchars($_POST['pai']);
    $endereco = htmlspecialchars($_POST['endereco']);
    $data_nascimento = htmlspecialchars($_POST['data_nascimento']);
    $escolaridade_mae = htmlspecialchars($_POST['escolaridade_mae']);
    $escolaridade_pai = htmlspecialchars($_POST['escolaridade_pai']);

    $dados = "Nome Completo do Aluno: $nome\n";
    $dados .= "Nome da Mãe: $mae\n";
    $dados .= "Nome do Pai: $pai\n";
    $dados .= "Endereço Completo: $endereco\n";
    $dados .= "Data de Nascimento: $data_nascimento\n";
    $dados .= "Escolaridade da Mãe: $escolaridade_mae\n";
    $dados .= "Escolaridade do Pai: $escolaridade_pai\n";
    $dados .= "----------------------------------------\n";

    $arquivo = 'dados_alunos.txt';

    file_put_contents($arquivo, $dados, FILE_APPEND | LOCK_EX);

    echo "Dados salvos com sucesso!<br>";
    echo "<a href='formulario.html'>Voltar ao formulário</a>";
} else {
    echo "Método de requisição não permitido.";
}
?>

