<?php

$numero = (int)readline("Digite um número menor que 1000: ");

if ($numero >= 1000) {
    echo "O número deve ser menor que 1000.";
} else {
    echo "Números ímpares maiores que $numero e menores que 1000:<br>";
    
    for ($i = $numero + 1; $i < 1000; $i++) {
        if ($i % 2 != 0) {
            echo $i . "<br>";
        }
    }
}

?>

