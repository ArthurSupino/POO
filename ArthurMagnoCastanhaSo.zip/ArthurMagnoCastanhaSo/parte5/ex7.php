<?php

$valores = array();
$soma = 0;

// Leitura dos cinco valores
for ($i = 0; $i < 5; $i++) {
    $valores[] = (int)readline("Digite um valor inteiro: ");
    $soma += $valores[$i];
}

// Cálculo da média
$media = $soma / count($valores);

// Exibição dos valores superiores à média
echo "Valores superiores à média ($media):<br>";

foreach ($valores as $valor) {
    if ($valor > $media) {
        echo $valor . "<br>";
    }
}

?>

