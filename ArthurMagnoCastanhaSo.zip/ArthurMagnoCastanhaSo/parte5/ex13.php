<?php

$base = (int)readline("Digite o valor da base: ");
$potencia = (int)readline("Digite o valor da potência: ");

$resultado = pow($base, $potencia);

echo "O resultado de $base elevado à potência $potencia é: $resultado<br>";

?>

