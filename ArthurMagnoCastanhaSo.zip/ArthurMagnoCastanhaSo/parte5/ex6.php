<?php

$valores = array();

for ($i = 0; $i < 5; $i++) {
    $valores[] = (int)readline("Digite um valor inteiro: ");
}

$maior = max($valores);
$menor = min($valores);

echo "O maior valor é: " . $maior . "<br>";
echo "O menor valor é: " . $menor . "<br>";

?>

