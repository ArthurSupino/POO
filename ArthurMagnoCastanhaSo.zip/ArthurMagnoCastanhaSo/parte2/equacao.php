<?php

function calcularRaizes($a, $b, $c) {

    $delta = $b * $b - 4 * $a * $c;

    if ($a == 0) {
        return "O coeficiente 'a' não pode ser zero em uma equação do segundo grau.";
    }

    if ($delta > 0) {

        $raiz1 = (-$b + sqrt($delta)) / (2 * $a);
        $raiz2 = (-$b - sqrt($delta)) / (2 * $a);
        return array($raiz1, $raiz2);
    } elseif ($delta == 0) {

        $raiz = -$b / (2 * $a);
        return array($raiz);
    } else {
       
        return "A equação não possui raízes reais.";
    }
}
?>

