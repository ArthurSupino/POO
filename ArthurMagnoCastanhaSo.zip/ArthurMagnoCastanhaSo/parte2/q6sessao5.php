<?php
include 'equacao.php';
$a = 1;
$b = -3;
$c = 2;

$resultado = null;

calcularRaizes($a, $b, $c, $resultado);
echo "Coeficientes da equação: a = $a, b = $b, c = $c\n";
if (is_array($resultado)) {
    if (count($resultado) == 1) {
        echo "Raiz dupla: " . $resultado[0] . "\n";
    } elseif (count($resultado) == 2) {
        echo "Raízes distintas: " . $resultado[0] . " e " . $resultado[1] . "\n";
    }
} else {
    echo $resultado . "\n";
}
?>


