<?php
function fatorialIterativo($numero) {
    $fatorial = 1;
    for ($i = 2; $i <= $numero; $i++) {
        $fatorial *= $i;
    }
    return $fatorial;
}

$numero = 5;
echo "Fatorial de $numero (usando iteração): " . fatorialIterativo($numero) . "\n";
?>

