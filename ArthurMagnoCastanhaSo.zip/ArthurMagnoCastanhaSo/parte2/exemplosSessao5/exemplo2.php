<?php
 $total = 0;
 echo " percorreu 100 Km = " . km2mi (100) . " milhas <br > " ;
 echo " percorreu 200 Km = " . km2mi (200) . " milhas <br > " ;
 echo " percorreu no total " . $total . " kilometros = " . km2mi ( $total ) . " milhas <br > " ;
 function km2mi ( $kms ) {
 global $total ;
 $total += $kms ;
 return $kms *0.6;
 }
 ? >
