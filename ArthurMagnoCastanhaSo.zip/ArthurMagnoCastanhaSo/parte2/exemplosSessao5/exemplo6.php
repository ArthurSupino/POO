<?php
 // arquivo teste . php
 // usa as funcoes do arquivo biblioteca . php
 // carrega o arquivo biblioteca . php
 include ’ biblioteca . php ’;
 echo " 4 ao quadrado = " . quadrado (4) ;
 echo " <br > " ;
 echo " 3 + 2 = " . soma (3 ,2) ;
 echo " <br > " ;
?>
