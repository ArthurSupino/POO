<?php
 $a =10;
 echo " a = " . $a ; echo " <br > " ;
 Incrementa ( $a ,20) ;
 echo " fora da funcao ... " ;
 echo " a = " . $a ; echo " <br > " ;

 function Incrementa ( $variavel , $valor ) {
 $variavel += $valor ;
 echo " Dentro da funcao , variavel vale : " . $variavel . " <br > " ;
 }
 ?>
