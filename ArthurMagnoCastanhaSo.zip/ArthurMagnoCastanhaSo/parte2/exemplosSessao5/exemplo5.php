<?php
 $a =10;
 echo " a = " . $a ; echo " <br > " ;
 IncrementaX ( $a ,20) ;
 echo " fora da funcao ... " ;
 echo " a = " . $a ; echo " <br > " ;

 function IncrementaX (& $variavel , $valor ) {
 $variavel += $valor ;
 echo " Dentro da funcao , variavelo vale : " . $variavel . " <br > " ;
 }
 ?>
