<?php

 function soma ( $x , $y )
 {
return $x + $y ; }
$x =2; $y =3;
$z = soma ( $x , $y ) ;
echo $x . " + " . $y . " = " . $z . " <br > " ;
 ? >
