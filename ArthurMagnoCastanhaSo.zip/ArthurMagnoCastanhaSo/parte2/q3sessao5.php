<?php
function fatorialRecursivo($numero) {
    if ($numero <= 1) {
        return 1;
    } else {
        return $numero * fatorialRecursivo($numero - 1);
    }
}


$numero = 5;
echo "Fatorial de $numero (usando recursão): " . fatorialRecursivo($numero) . "\n";
?>

