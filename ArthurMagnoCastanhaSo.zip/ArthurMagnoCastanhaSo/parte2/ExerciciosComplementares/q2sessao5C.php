<?php
function verificarPalindromo($string) {
    $string = strtolower(preg_replace('/[^a-z0-9]/i', '', $string));
    return $string === strrev($string);
}

$string = "A man, a plan, a canal, Panama";
if (verificarPalindromo($string)) {
    echo "\"$string\" é um palíndromo.\n";
} else {
    echo "\"$string\" não é um palíndromo.\n";
}
?>

