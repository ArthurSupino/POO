<?php
function calcularProdutosVetoriais($v1, $v2) {
    $produtoEscalar = $v1[0] * $v2[0] + $v1[1] * $v2[1] + $v1[2] * $v2[2];
    $produtoVetorial = array(
        $v1[1] * $v2[2] - $v1[2] * $v2[1],
        $v1[2] * $v2[0] - $v1[0] * $v2[2],
        $v1[0] * $v2[1] - $v1[1] * $v2[0]
    );
    return array('produtoEscalar' => $produtoEscalar, 'produtoVetorial' => $produtoVetorial);
}

$vetor1 = array(1, 2, 3);
$vetor2 = array(4, 5, 6);

$resultados = calcularProdutosVetoriais($vetor1, $vetor2);

echo "Produto Escalar: " . $resultados['produtoEscalar'] . "\n";
echo "Produto Vetorial: (" . $resultados['produtoVetorial'][0] . ", " . $resultados['produtoVetorial'][1] . ", " . $resultados['produtoVetorial'][2] . ")\n";
?>

