<?php
function verificarPrimo($numero) {

    if ($numero <= 1) {
        return false;
    }

    for ($i = 2; $i <= sqrt($numero); $i++) {
        if ($numero % $i == 0) {
            return false;
        }
    }

    return true;
}


$numero = 29;

if (verificarPrimo($numero)) {
    echo "$numero é um número primo.\n";
} else {
    echo "$numero não é um número primo.\n";
}
?>

