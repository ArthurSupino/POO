<?php
function inverterString($string) {
    return strrev($string);
}

$string = "Para Casa";
$inversa = inverterString($string);

echo "Original: $string\n";
echo "Invertida: $inversa\n";
?>

